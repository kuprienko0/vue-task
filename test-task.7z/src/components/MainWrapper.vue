<template>
  <v-container>
    <v-row class="text-center d-flex">
      <router-view>

      </router-view>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "MainWrapper"
}
</script>

<style scoped>

</style>