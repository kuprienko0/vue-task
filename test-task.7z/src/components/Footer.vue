<template>
  <v-footer padless
  fixed="fixed">
    <v-col
        class="text-center"
        cols="12"
    >
      <strong>Test Task</strong>
    </v-col>
  </v-footer>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>